
import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Waves, Volume2, ShieldCheck, Zap } from 'lucide-react';

interface LiveVoiceProps {
  isActive: boolean;
  isSpeaking: boolean;
  transcript: string;
}

export const LiveVoice: React.FC<LiveVoiceProps> = ({ isActive, isSpeaking, transcript }) => {
  const [bars, setBars] = useState<number[]>(new Array(12).fill(4));

  useEffect(() => {
    let interval: any;
    if (isActive) {
      interval = setInterval(() => {
        setBars(new Array(12).fill(0).map(() => 
          isSpeaking ? Math.random() * 24 + 8 : Math.random() * 6 + 2
        ));
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isActive, isSpeaking]);

  return (
    <div className={`p-6 rounded-3xl border transition-all duration-500 flex flex-col items-center gap-6 ${
      isActive ? 'bg-indigo-500/10 border-indigo-500/30' : 'bg-zinc-900/50 border-white/5 opacity-50'
    }`}>
      <div className="relative">
        <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-500 ${
          isActive ? 'bg-indigo-500 shadow-[0_0_30px_rgba(99,102,241,0.5)]' : 'bg-zinc-800'
        }`}>
          {isActive ? <Mic className="w-8 h-8 text-white" /> : <MicOff className="w-8 h-8 text-zinc-500" />}
        </div>
        {isActive && (
          <div className="absolute inset-0 rounded-full border-2 border-indigo-500 animate-ping opacity-20"></div>
        )}
      </div>

      <div className="flex gap-1.5 h-10 items-center">
        {bars.map((h, i) => (
          <div 
            key={i} 
            className={`w-1.5 rounded-full transition-all duration-150 ${isActive ? 'bg-indigo-400' : 'bg-zinc-700'}`}
            style={{ height: `${h}px` }}
          ></div>
        ))}
      </div>

      <div className="text-center space-y-2 max-w-xs">
        <div className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-400">
          {isActive ? (isSpeaking ? 'Cipher is transmitting...' : 'Awaiting input...') : 'Neural Link Offline'}
        </div>
        <p className="text-xs text-zinc-400 italic line-clamp-2 h-8">
          {transcript || 'Establish a secure link to begin verbal synthesis.'}
        </p>
      </div>

      <div className="flex gap-4">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-950 border border-white/5">
          <ShieldCheck className="w-3 h-3 text-emerald-500" />
          <span className="text-[8px] mono text-zinc-500 font-bold uppercase">Encrypted</span>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-950 border border-white/5">
          <Zap className="w-3 h-3 text-amber-500" />
          <span className="text-[8px] mono text-zinc-500 font-bold uppercase">Low Latency</span>
        </div>
      </div>
    </div>
  );
};
