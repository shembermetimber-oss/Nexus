
import React, { useState, useEffect } from 'react';
import { Cpu, Server, Zap, Brain, Activity, RefreshCw, X, Database, Gauge } from 'lucide-react';

interface LLMArchitectLabProps {
  onClose: () => void;
}

export const LLMArchitectLab: React.FC<LLMArchitectLabProps> = ({ onClose }) => {
  const [archType, setArchType] = useState<'dense' | 'moe'>('moe');
  const [params, setParams] = useState(7);
  const [gpus, setGpus] = useState(8);
  const [isTraining, setIsTraining] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const [metrics, setMetrics] = useState({ loss: 2.5, tokens: 0, mfu: 0 });

  useEffect(() => {
    if (isTraining) {
      const interval = setInterval(() => {
        setMetrics(prev => ({
          loss: Math.max(0.12, prev.loss - (Math.random() * 0.05)),
          tokens: prev.tokens + (gpus * 1200000),
          mfu: Math.min(65, 45 + Math.random() * 20)
        }));
        
        const events = [
          `[RANK 0] Checkpoint saved at step ${Math.floor(metrics.tokens/1000000)}M`,
          `[SYSTEM] Gradient norm stable: 0.85`,
          `[COMPUTE] GPU utilization at ${metrics.mfu.toFixed(1)}%`,
          `[DATA] Pipeline processing: ${archType === 'moe' ? 'Active Experts: 2/8' : 'Dense pass'}`
        ];
        setLog(prev => [...prev.slice(-8), events[Math.floor(Math.random() * events.length)]]);
      }, 800);
      return () => clearInterval(interval);
    }
  }, [isTraining, gpus, archType, metrics.tokens, metrics.mfu]);

  const handleInit = () => {
    setLog([`[INIT] Initializing ${params}B Parameter ${archType.toUpperCase()} Model...`, `[INIT] Provisioning ${gpus}x NVIDIA H100 Cluster...`]);
    setIsTraining(true);
  };

  return (
    <div className="w-full bg-[#0a0a0f] rounded-2xl border border-indigo-500/30 overflow-hidden flex flex-col shadow-[0_0_50px_rgba(79,70,229,0.15)] animate-in fade-in duration-500">
      <div className="bg-indigo-500/10 px-4 py-3 flex items-center justify-between border-b border-indigo-500/20">
        <div className="flex items-center gap-2 text-indigo-400">
          <Brain className="w-5 h-5" />
          <span className="text-xs font-bold tracking-widest uppercase mono italic">Project DeepForge v4.2</span>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-lg transition-colors">
          <X className="w-4 h-4 text-zinc-500" />
        </button>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Configuration */}
        <div className="lg:col-span-4 space-y-6">
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
              <Server className="w-4 h-4" /> Cluster Config
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-[10px] text-zinc-500 font-bold block mb-2">Architecture Strategy</label>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => setArchType('dense')}
                    className={`py-2 text-xs font-bold rounded border ${archType === 'dense' ? 'bg-indigo-500 text-white border-indigo-400' : 'bg-zinc-900 text-zinc-500 border-zinc-800'}`}
                  >
                    DENSE
                  </button>
                  <button 
                    onClick={() => setArchType('moe')}
                    className={`py-2 text-xs font-bold rounded border ${archType === 'moe' ? 'bg-indigo-500 text-white border-indigo-400' : 'bg-zinc-900 text-zinc-500 border-zinc-800'}`}
                  >
                    MOE (Expert)
                  </button>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <label className="text-[10px] text-zinc-500 font-bold">Parameters</label>
                  <span className="text-xs mono text-indigo-400">{params}B</span>
                </div>
                <input type="range" min="1" max="175" value={params} onChange={(e) => setParams(Number(e.target.value))} className="w-full accent-indigo-500" />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <label className="text-[10px] text-zinc-500 font-bold">Compute Power (H100s)</label>
                  <span className="text-xs mono text-indigo-400">{gpus}x</span>
                </div>
                <input type="range" min="8" max="1024" step="8" value={gpus} onChange={(e) => setGpus(Number(e.target.value))} className="w-full accent-indigo-500" />
              </div>
            </div>
          </div>

          <button 
            onClick={handleInit}
            disabled={isTraining}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 rounded-xl font-black text-xs tracking-[0.2em] transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20"
          >
            {isTraining ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4 fill-current" />}
            INITIATE TRAINING
          </button>
        </div>

        {/* Right: Monitoring */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-zinc-900/50 p-4 rounded-xl border border-white/5 flex flex-col items-center">
              <Database className="w-4 h-4 text-blue-400 mb-2" />
              <span className="text-[10px] text-zinc-500 font-bold uppercase">Tokens Seen</span>
              <span className="text-lg mono text-white">{(metrics.tokens / 1e9).toFixed(2)}B</span>
            </div>
            <div className="bg-zinc-900/50 p-4 rounded-xl border border-white/5 flex flex-col items-center">
              <Activity className="w-4 h-4 text-green-400 mb-2" />
              <span className="text-[10px] text-zinc-500 font-bold uppercase">Train Loss</span>
              <span className="text-lg mono text-white">{metrics.loss.toFixed(4)}</span>
            </div>
            <div className="bg-zinc-900/50 p-4 rounded-xl border border-white/5 flex flex-col items-center">
              <Gauge className="w-4 h-4 text-indigo-400 mb-2" />
              <span className="text-[10px] text-zinc-500 font-bold uppercase">GPU MFU</span>
              <span className="text-lg mono text-white">{metrics.mfu.toFixed(1)}%</span>
            </div>
          </div>

          <div className="flex-1 bg-black p-4 rounded-xl border border-white/5 font-mono text-[11px] overflow-hidden flex flex-col">
            <div className="flex justify-between items-center mb-2 pb-2 border-b border-white/10">
              <span className="text-zinc-600 uppercase tracking-widest text-[9px]">Live Cluster Logs</span>
              <div className="flex gap-1">
                <div className="w-1 h-1 rounded-full bg-red-500 animate-pulse"></div>
                <div className="w-1 h-1 rounded-full bg-green-500 animate-pulse"></div>
              </div>
            </div>
            <div className="flex-1 space-y-1 overflow-y-auto">
              {log.map((l, i) => (
                <div key={i} className={l.includes('ERROR') ? 'text-red-400' : l.includes('SUCCESS') ? 'text-green-400' : 'text-zinc-400'}>
                  {l}
                </div>
              ))}
              {isTraining && <div className="text-indigo-500 animate-pulse">_</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
