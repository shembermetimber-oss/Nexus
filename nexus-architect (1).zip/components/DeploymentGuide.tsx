
import React, { useState } from 'react';
import { X, Github, Globe, Terminal, Copy, Check, UploadCloud, Zap, Package, MousePointer2 } from 'lucide-react';

interface DeploymentGuideProps {
  onClose: () => void;
}

export const DeploymentGuide: React.FC<DeploymentGuideProps> = ({ onClose }) => {
  const [copied, setCopied] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'git' | 'direct'>('git');

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const gitSteps = [
    {
      title: "1. Initialize Local Core",
      cmd: "git init\ngit add .\ngit commit -m \"Initial neural sync\"",
      id: "step1"
    },
    {
      title: "2. Link Remote Repository",
      cmd: "git remote add origin <your-repo-url>\ngit branch -M main",
      id: "step2"
    },
    {
      title: "3. Push to Global Grid",
      cmd: "git push -u origin main",
      id: "step3"
    }
  ];

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="w-full max-w-2xl glass-panel border border-rose-500/30 rounded-[2.5rem] overflow-hidden shadow-[0_0_120px_rgba(244,63,94,0.2)] animate-in zoom-in-95 duration-500">
        
        {/* Header & Tabs */}
        <div className="bg-rose-500/5 border-b border-rose-500/10">
          <div className="px-8 py-5 flex items-center justify-between">
            <div className="flex items-center gap-3 text-rose-500">
              <Zap className="w-6 h-6 animate-pulse" />
              <span className="text-[10px] font-black tracking-[0.4em] uppercase">Deployment Manual // Protocol 0-1</span>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-xl transition-colors">
              <X className="w-5 h-5 text-zinc-500" />
            </button>
          </div>
          
          <div className="flex px-8 gap-8 border-t border-white/5">
            <button 
              onClick={() => setActiveTab('git')}
              className={`py-4 text-[10px] font-black uppercase tracking-[0.2em] transition-all relative ${activeTab === 'git' ? 'text-white' : 'text-zinc-600 hover:text-zinc-400'}`}
            >
              Git_Synchronization
              {activeTab === 'git' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,1)]"></div>}
            </button>
            <button 
              onClick={() => setActiveTab('direct')}
              className={`py-4 text-[10px] font-black uppercase tracking-[0.2em] transition-all relative ${activeTab === 'direct' ? 'text-white' : 'text-zinc-600 hover:text-zinc-400'}`}
            >
              Direct_Uplink
              {activeTab === 'direct' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,1)]"></div>}
            </button>
          </div>
        </div>

        <div className="p-8 space-y-8 max-h-[60vh] overflow-y-auto custom-scrollbar">
          {activeTab === 'git' ? (
            <div className="space-y-8 animate-in slide-in-from-left-4 duration-300">
              <div className="space-y-4">
                <h3 className="text-xl font-black text-white uppercase tracking-tighter">Terminal Synchronization</h3>
                <p className="text-zinc-400 text-sm leading-relaxed font-medium">
                  The professional method. Version-controlled deployment via the GitHub backbone.
                </p>
              </div>

              <div className="space-y-6">
                {gitSteps.map((step) => (
                  <div key={step.id} className="space-y-3">
                    <div className="text-[10px] font-black text-rose-500/70 uppercase tracking-widest flex items-center gap-2">
                       <Terminal className="w-3 h-3" /> {step.title}
                    </div>
                    <div className="relative group">
                      <pre className="bg-black border border-white/5 p-5 rounded-2xl mono text-[12px] text-zinc-300 overflow-x-auto selection:bg-rose-500/30">
                        {step.cmd}
                      </pre>
                      <button 
                        onClick={() => copyToClipboard(step.cmd, step.id)}
                        className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-all"
                      >
                        {copied === step.id ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4 text-zinc-500" />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
              <div className="space-y-4">
                <h3 className="text-xl font-black text-white uppercase tracking-tighter">Direct Folder Upload</h3>
                <p className="text-zinc-400 text-sm leading-relaxed font-medium">
                  The tactical shortcut. Deploy your nexus core without touching a single line of Git code.
                </p>
              </div>

              <div className="space-y-10">
                <div className="flex flex-col items-center gap-6 p-8 rounded-[2.5rem] bg-rose-500/5 border border-dashed border-rose-500/20 text-center">
                   <div className="w-20 h-20 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-500 border border-rose-500/30 cyber-glow shadow-[0_0_30px_rgba(244,63,94,0.2)]">
                      <MousePointer2 className="w-10 h-10 animate-bounce" />
                   </div>
                   <div className="space-y-2">
                      <div className="text-xs font-black text-white uppercase tracking-widest">Step 1: Build & Zip</div>
                      <p className="text-[11px] text-zinc-500 uppercase tracking-widest leading-none">Export your project as a static bundle.</p>
                   </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <a 
                    href="https://app.netlify.com/drop" 
                    target="_blank" 
                    className="p-6 rounded-3xl bg-zinc-900 border border-white/5 hover:border-indigo-500/40 hover:bg-indigo-500/5 transition-all group flex flex-col gap-4"
                  >
                    <div className="flex items-center justify-between">
                      <div className="p-3 rounded-2xl bg-white/5 text-indigo-400 group-hover:scale-110 transition-transform">
                        <UploadCloud className="w-6 h-6" />
                      </div>
                      <Globe className="w-4 h-4 text-zinc-800" />
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs font-black text-white uppercase tracking-widest">Netlify Drop</div>
                      <p className="text-[10px] text-zinc-600 font-bold uppercase leading-tight">Drag your folder directly onto their site to go live instantly.</p>
                    </div>
                  </a>

                  <div className="p-6 rounded-3xl bg-zinc-900 border border-white/5 hover:border-rose-500/40 hover:bg-rose-500/5 transition-all group flex flex-col gap-4 cursor-default">
                    <div className="flex items-center justify-between">
                      <div className="p-3 rounded-2xl bg-white/5 text-rose-400 group-hover:scale-110 transition-transform">
                        <Package className="w-6 h-6" />
                      </div>
                      <Zap className="w-4 h-4 text-zinc-800" />
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs font-black text-white uppercase tracking-widest">Vercel Direct</div>
                      <p className="text-[10px] text-zinc-600 font-bold uppercase leading-tight">Upload your tactical bundle to the Vercel cloud architecture.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="p-6 rounded-3xl bg-zinc-900/50 border border-white/5 flex items-start gap-5">
            <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-400">
               <Globe className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <div className="text-[11px] font-black text-white uppercase tracking-widest">Network Status</div>
              <p className="text-[12px] text-zinc-500 leading-relaxed font-medium">
                The <strong className="text-indigo-400">NEXUS Core</strong> is highly optimized. Once uploaded, your app will automatically scale to billions of nodes across the global mesh.
              </p>
            </div>
          </div>
        </div>

        <div className="p-8 bg-zinc-950/80 border-t border-white/5 backdrop-blur-xl">
          <button 
            onClick={onClose}
            className="w-full py-5 bg-white text-black font-black uppercase tracking-[0.4em] text-[11px] rounded-[1.5rem] hover:bg-zinc-200 transition-all shadow-[0_0_40px_rgba(255,255,255,0.1)] active:scale-[0.98]"
          >
            Acknowledge Protocols
          </button>
        </div>
      </div>
    </div>
  );
};
