
import React, { useState, useEffect } from 'react';
import { Cpu, Zap, Activity, RefreshCw, X, BrainCircuit } from 'lucide-react';

interface AIBuilderLabProps {
  onClose: () => void;
  onComplete: (accuracy: number) => void;
}

export const AIBuilderLab: React.FC<AIBuilderLabProps> = ({ onClose, onComplete }) => {
  const [layers, setLayers] = useState(3);
  const [learningRate, setLearningRate] = useState(0.01);
  const [isTraining, setIsTraining] = useState(false);
  const [progress, setProgress] = useState(0);
  const [accuracy, setAccuracy] = useState(0);
  const [loss, setLoss] = useState(1.0);

  useEffect(() => {
    let interval: any;
    if (isTraining && progress < 100) {
      interval = setInterval(() => {
        setProgress(prev => {
          const next = prev + 2;
          // Simulated metrics based on layers and learning rate
          const targetAccuracy = 70 + (layers * 2) - (Math.abs(0.05 - learningRate) * 50);
          setAccuracy(Math.min(99.9, (next / 100) * targetAccuracy + (Math.random() * 2)));
          setLoss(Math.max(0.01, 1.0 - (next / 100) * 0.9 + (Math.random() * 0.05)));
          
          if (next >= 100) {
            setIsTraining(false);
            onComplete(accuracy);
          }
          return next;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isTraining, progress, layers, learningRate, accuracy, onComplete]);

  const startTraining = () => {
    setProgress(0);
    setAccuracy(0);
    setLoss(1.0);
    setIsTraining(true);
  };

  return (
    <div className="w-full bg-zinc-950 rounded-2xl border border-blue-500/30 overflow-hidden flex flex-col relative animate-in zoom-in-95 duration-300 shadow-[0_0_40px_rgba(59,130,246,0.15)]">
      {/* Header */}
      <div className="bg-blue-500/10 px-4 py-3 flex items-center justify-between border-b border-blue-500/20">
        <div className="flex items-center gap-2 text-blue-400">
          <Cpu className="w-5 h-5" />
          <span className="text-xs font-bold tracking-widest uppercase mono">Neural Forge v1.0</span>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-lg transition-colors">
          <X className="w-4 h-4 text-zinc-500" />
        </button>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Controls */}
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-white">
              <Zap className="w-4 h-4 text-yellow-400" /> Model Configuration
            </h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-xs text-zinc-400 uppercase font-bold">Hidden Layers</label>
                  <span className="text-xs mono text-blue-400">{layers}</span>
                </div>
                <input 
                  type="range" min="1" max="12" step="1"
                  value={layers}
                  onChange={(e) => setLayers(parseInt(e.target.value))}
                  disabled={isTraining}
                  className="w-full accent-blue-500 bg-zinc-800 rounded-lg h-1.5 appearance-none cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-xs text-zinc-400 uppercase font-bold">Learning Rate</label>
                  <span className="text-xs mono text-blue-400">{learningRate.toFixed(3)}</span>
                </div>
                <input 
                  type="range" min="0.001" max="0.1" step="0.001"
                  value={learningRate}
                  onChange={(e) => setLearningRate(parseFloat(e.target.value))}
                  disabled={isTraining}
                  className="w-full accent-blue-500 bg-zinc-800 rounded-lg h-1.5 appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="p-4 bg-zinc-900/50 rounded-xl border border-white/5 space-y-3">
            <div className="flex justify-between text-[10px] uppercase font-bold tracking-tighter text-zinc-500">
              <span>Metric</span>
              <span>Value</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-zinc-300">Accuracy</span>
              <span className="text-sm mono text-green-400">{accuracy.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-zinc-300">Loss</span>
              <span className="text-sm mono text-red-400">{loss.toFixed(4)}</span>
            </div>
            <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden mt-2 relative">
              <div 
                className="h-full bg-blue-500 transition-all duration-300 shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>

          <button 
            onClick={startTraining}
            disabled={isTraining}
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20"
          >
            {isTraining ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4 fill-current" />}
            {isTraining ? 'Training Architecture...' : 'Start Training Cycle'}
          </button>
        </div>

        {/* Visualization */}
        <div className="bg-black/40 rounded-xl border border-white/5 p-4 flex flex-col items-center justify-center space-y-6 min-h-[300px]">
           <div className="relative w-full aspect-square max-w-[200px] flex items-center justify-center">
              <div className={`absolute inset-0 border-4 border-dashed border-blue-500/20 rounded-full ${isTraining ? 'animate-[spin_10s_linear_infinite]' : ''}`}></div>
              <div className="z-10 bg-zinc-900 p-6 rounded-full border border-blue-500/50 shadow-[0_0_30px_rgba(59,130,246,0.2)]">
                <BrainCircuit className="w-12 h-12 text-blue-400" />
              </div>
              
              {/* Animated orbital nodes */}
              {[0, 90, 180, 270].map((angle, idx) => (
                <div 
                  key={idx}
                  className={`absolute w-4 h-4 bg-blue-500 rounded-full shadow-[0_0_15px_rgba(59,130,246,0.8)] transition-all duration-500`}
                  style={{
                    transform: `rotate(${angle + (isTraining ? progress * 3.6 : 0)}deg) translateY(-100px)`
                  }}
                ></div>
              ))}
           </div>
           <div className="text-center">
             <p className="text-[10px] mono text-zinc-500 uppercase tracking-widest leading-relaxed">
               Simulating Synaptic Weights<br/>Layer Topology: {layers} Deep
             </p>
             {isTraining && (
               <div className="mt-2 text-[9px] text-blue-400 mono animate-pulse">
                 FEED_FORWARDING... BACK_PROPAGATING...
               </div>
             )}
           </div>
        </div>
      </div>
    </div>
  );
};
