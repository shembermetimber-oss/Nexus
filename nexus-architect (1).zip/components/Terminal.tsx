
import React, { useState, useRef, useEffect } from 'react';
import { TerminalLine } from '../types';
import { Terminal as TerminalIcon, Maximize2, X } from 'lucide-react';

export const Terminal: React.FC = () => {
  const [history, setHistory] = useState<TerminalLine[]>([
    { text: 'NEXUS ARCHITECT // SHELL_v10.0', type: 'success' },
    { text: 'LINK STATUS: ENCRYPTED // AES-512', type: 'output' },
    { text: 'Directives awaited...', type: 'output' },
  ]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history]);

  const handleCommand = (cmd: string) => {
    const trimmedCmd = cmd.trim().toLowerCase();
    const newHistory: TerminalLine[] = [...history, { text: `commander@nexus:~$ ${cmd}`, type: 'input' }];

    switch (trimmedCmd) {
      case 'help':
        newHistory.push({ text: 'available: manifest, reset, identity, scan, vulnerability, status', type: 'output' });
        break;
      case 'reset':
        setHistory([]);
        return;
      case 'identity':
        newHistory.push({ text: 'ARCHITECT_CORE_01 [LEVEL: OMEGA]', type: 'output' });
        break;
      case 'scan':
        newHistory.push({ text: '[!] Initializing deep network topology scan...', type: 'output' });
        newHistory.push({ text: '[OK] Perimeter breach detected at Node 42.', type: 'error' });
        newHistory.push({ text: '[OK] Firewall re-routing active.', type: 'success' });
        break;
      case 'status':
        newHistory.push({ text: 'CORE TEMPERATURE: OPTIMAL [32°C]', type: 'success' });
        newHistory.push({ text: 'NEURAL LOAD: 14%', type: 'output' });
        break;
      case '':
        break;
      default:
        newHistory.push({ text: `UNRECOGNIZED DIRECTIVE: ${trimmedCmd}`, type: 'error' });
    }

    setHistory(newHistory);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input) {
      handleCommand(input);
      setInput('');
    }
  };

  return (
    <div className="w-full h-96 bg-black rounded-3xl border border-white/5 overflow-hidden flex flex-col shadow-2xl relative">
      <div className="absolute inset-0 pointer-events-none opacity-[0.15]" style={{ 
        backgroundImage: 'linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.5) 50%), linear-gradient(90deg, rgba(99, 102, 241, 0.1), rgba(34, 211, 238, 0.05), rgba(99, 102, 241, 0.1))',
        backgroundSize: '100% 2px, 2px 100%' 
      }}></div>

      <div className="bg-zinc-900/40 px-6 py-4 flex items-center justify-between border-b border-white/5 backdrop-blur-xl">
        <div className="flex items-center gap-4">
          <div className="flex gap-2">
             <div className="w-3 h-3 rounded-full bg-rose-500/20 border border-rose-500/40 shadow-[0_0_8px_rgba(244,63,94,0.3)]"></div>
             <div className="w-3 h-3 rounded-full bg-amber-500/20 border border-amber-500/40 shadow-[0_0_8px_rgba(245,158,11,0.3)]"></div>
             <div className="w-3 h-3 rounded-full bg-emerald-500/20 border border-emerald-500/40 shadow-[0_0_8px_rgba(16,185,129,0.3)]"></div>
          </div>
          <div className="flex items-center gap-3">
            <TerminalIcon className="w-4 h-4 text-indigo-500 cyber-glow" />
            <span className="text-[11px] text-zinc-400 font-black uppercase tracking-[0.4em]">Tactical Interface</span>
          </div>
        </div>
        <div className="flex gap-4">
           <Maximize2 className="w-4 h-4 text-zinc-700 hover:text-white cursor-pointer transition-colors" />
           <X className="w-4 h-4 text-zinc-700 hover:text-rose-500 cursor-pointer transition-colors" />
        </div>
      </div>
      
      <div ref={scrollRef} className="flex-1 p-8 overflow-y-auto mono text-[13px] space-y-2 relative scroll-smooth">
        {history.map((line, i) => (
          <div 
            key={i} 
            className={`
              ${line.type === 'input' ? 'text-white font-bold text-glow-indigo' : ''}
              ${line.type === 'error' ? 'text-rose-400/90' : ''}
              ${line.type === 'success' ? 'text-indigo-400 font-black tracking-wide' : ''}
              ${line.type === 'output' ? 'text-zinc-600' : ''}
              animate-in fade-in slide-in-from-left-2 duration-300
            `}
          >
            {line.text}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="px-8 py-5 border-t border-white/5 flex items-center bg-black/40">
        <span className="mono text-indigo-500 mr-4 text-lg font-black animate-pulse">#</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="bg-transparent border-none outline-none flex-1 mono text-white text-sm placeholder:text-zinc-800"
          autoFocus
          placeholder="Execute protocol..."
        />
        <div className="text-[10px] mono text-indigo-900 font-black uppercase tracking-widest hidden sm:block">Link: Active</div>
      </form>
    </div>
  );
};
