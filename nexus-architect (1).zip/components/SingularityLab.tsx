
import React, { useState, useEffect } from 'react';
import { Sparkles, Brain, Cpu, X, Zap, RefreshCw, Layers, ShieldAlert } from 'lucide-react';

export const SingularityLab: React.FC<{ onClose: () => void, type: 'swarm' | 'quantum' }> = ({ onClose, type }) => {
  const [agents, setAgents] = useState(128);
  const [efficiency, setEfficiency] = useState(0);
  const [isSynthesizing, setIsSynthesizing] = useState(false);

  useEffect(() => {
    let interval: any;
    if (isSynthesizing) {
      interval = setInterval(() => {
        setEfficiency(prev => Math.min(100, prev + (Math.random() * 5)));
      }, 200);
    }
    return () => clearInterval(interval);
  }, [isSynthesizing]);

  return (
    <div className="w-full bg-[#050005] rounded-2xl border border-fuchsia-500/30 overflow-hidden flex flex-col shadow-[0_0_80px_rgba(217,70,239,0.1)]">
      <div className="bg-fuchsia-500/10 px-4 py-3 flex items-center justify-between border-b border-fuchsia-500/20">
        <div className="flex items-center gap-2 text-fuchsia-400">
          <Sparkles className="w-5 h-5" />
          <span className="text-xs font-black tracking-widest uppercase mono">NEXUS_SINGULARITY // {type.toUpperCase()}</span>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-lg">
          <X className="w-4 h-4 text-zinc-500" />
        </button>
      </div>

      <div className="p-8 grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="space-y-8">
           <div className="space-y-2">
              <h2 className="text-2xl font-black text-white uppercase tracking-tighter">
                {type === 'swarm' ? 'Neural Swarm Integration' : 'Post-Quantum Synthesis'}
              </h2>
              <p className="text-zinc-500 text-sm">
                Recursive optimization protocols active. Adjust hive density for maximum throughput.
              </p>
           </div>

           <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">{type === 'swarm' ? 'Hive Density' : 'Qubit Stability'}</label>
                  <span className="text-xs mono text-fuchsia-400">{agents}{type === 'swarm' ? ' Agents' : 'σ'}</span>
                </div>
                <input type="range" min="8" max="1024" value={agents} onChange={(e) => setAgents(Number(e.target.value))} className="w-full accent-fuchsia-500" />
              </div>

              <div className="p-4 rounded-xl bg-zinc-900 border border-white/5 flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-black text-zinc-500 uppercase">Current Efficiency</div>
                  <div className="text-xl font-black text-white mono">{efficiency.toFixed(1)}%</div>
                </div>
                <div className={`p-3 rounded-xl bg-fuchsia-500/10 text-fuchsia-400 ${isSynthesizing ? 'animate-pulse' : ''}`}>
                   {type === 'swarm' ? <Brain className="w-6 h-6" /> : <Layers className="w-6 h-6" />}
                </div>
              </div>

              <button 
                onClick={() => setIsSynthesizing(true)}
                className="w-full py-4 bg-fuchsia-600 hover:bg-fuchsia-500 text-white font-black uppercase tracking-[0.3em] text-[10px] rounded-2xl shadow-2xl shadow-fuchsia-500/20 transition-all"
              >
                {isSynthesizing ? 'SYNTHESIZING...' : 'INITIATE THRESHOLD'}
              </button>
           </div>
        </div>

        <div className="flex items-center justify-center relative">
           <div className={`absolute w-48 h-48 bg-fuchsia-500/20 blur-[100px] rounded-full ${isSynthesizing ? 'animate-pulse' : ''}`}></div>
           <div className="relative w-full aspect-square border border-fuchsia-500/20 rounded-full flex items-center justify-center p-8">
              <div className={`w-full h-full border-2 border-dashed border-fuchsia-500/10 rounded-full ${isSynthesizing ? 'animate-spin' : ''}`} style={{ animationDuration: '20s' }}></div>
              <div className={`absolute inset-0 flex items-center justify-center`}>
                 <Zap className={`w-12 h-12 text-fuchsia-400 ${isSynthesizing ? 'animate-bounce' : ''}`} />
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
