
import React, { useState, useEffect } from 'react';
import { Music, SkipForward, Play, Pause, Volume2, Radio } from 'lucide-react';

export const PhonkFM: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState('NEXUS_CORE // VOID_WALKER');
  const [visualizer, setVisualizer] = useState<number[]>(new Array(12).fill(2));

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setVisualizer(new Array(12).fill(0).map(() => Math.floor(Math.random() * 24) + 4));
      }, 100);
    } else {
      setVisualizer(new Array(12).fill(2));
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const tracks = [
    'NEXUS_CORE // VOID_WALKER',
    'SLAUGHTER_HOUSE [NEXUS EDIT]',
    'PHONK_DRIFT_04',
    'CYBER_SHADOWS_V2',
    'SILENCE_IS_DEATH'
  ];

  const nextTrack = () => {
    const nextIdx = (tracks.indexOf(currentTrack) + 1) % tracks.length;
    setCurrentTrack(tracks[nextIdx]);
  };

  return (
    <div className="bg-black/80 backdrop-blur-xl border border-white/5 rounded-[2rem] p-5 flex flex-col gap-4 shadow-2xl group transition-all hover:border-indigo-500/20">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Radio className={`w-4 h-4 text-rose-500 ${isPlaying ? 'animate-pulse cyber-glow' : 'opacity-40'}`} />
          <span className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-600 group-hover:text-zinc-400 transition-colors">Neural Phonk FM</span>
        </div>
        <div className="flex gap-1 h-5 items-end">
          {visualizer.map((h, i) => (
            <div 
              key={i} 
              className={`w-1 transition-all duration-150 rounded-full ${isPlaying ? 'bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]' : 'bg-zinc-800'}`} 
              style={{ height: `${h}px` }}
            ></div>
          ))}
        </div>
      </div>
      
      <div className="bg-zinc-950 rounded-2xl p-4 border border-white/5">
        <div className="text-[11px] mono text-white truncate mb-2 font-bold tracking-tight text-glow-indigo">{currentTrack}</div>
        <div className="flex items-center justify-between mt-4">
          <div className="flex gap-3">
            <button onClick={() => setIsPlaying(!isPlaying)} className="p-2 bg-indigo-500/10 hover:bg-indigo-500/20 rounded-xl transition-all hover:scale-105 active:scale-90 border border-indigo-500/10">
              {isPlaying ? <Pause className="w-4 h-4 text-indigo-400" /> : <Play className="w-4 h-4 text-indigo-400 fill-current" />}
            </button>
            <button onClick={nextTrack} className="p-2 bg-white/5 hover:bg-white/10 rounded-xl transition-all hover:scale-105 active:scale-90 border border-white/5">
              <SkipForward className="w-4 h-4 text-zinc-400" />
            </button>
          </div>
          <div className="p-2 rounded-xl bg-white/5">
            <Volume2 className="w-4 h-4 text-zinc-700" />
          </div>
        </div>
      </div>
    </div>
  );
};
