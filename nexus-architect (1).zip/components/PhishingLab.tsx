
import React, { useState } from 'react';
import { ShieldAlert, Info, AlertCircle, X } from 'lucide-react';

interface PhishingLabProps {
  onClose: () => void;
  onAttempt: (user: string, pass: string) => void;
}

export const PhishingLab: React.FC<PhishingLabProps> = ({ onClose, onAttempt }) => {
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [isIntercepted, setIsIntercepted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsIntercepted(true);
    onAttempt(user, pass);
  };

  return (
    <div className="w-full bg-zinc-900 rounded-2xl border border-yellow-500/30 overflow-hidden flex flex-col relative animate-in zoom-in-95 duration-300">
      <div className="bg-yellow-500/10 px-4 py-3 flex items-center justify-between border-b border-yellow-500/20">
        <div className="flex items-center gap-2 text-yellow-500">
          <ShieldAlert className="w-5 h-5" />
          <span className="text-sm font-bold tracking-tight uppercase">Simulation: Credential Harvesting Lab</span>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-lg transition-colors">
          <X className="w-4 h-4 text-zinc-500" />
        </button>
      </div>

      <div className="p-8 flex flex-col items-center">
        {!isIntercepted ? (
          <div className="w-full max-w-sm space-y-6">
            <div className="text-center">
              <div className="text-3xl font-black text-white tracking-tighter mb-1">ROBLOX</div>
              <p className="text-zinc-400 text-sm italic">"Login to claim your 10,000 FREE ROBUX!"</p>
              <div className="mt-2 text-[10px] bg-red-500/20 text-red-400 py-1 rounded border border-red-500/30 font-mono">
                URL: http://roblox-rewards-generator.xyz/login
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Username/Email/Phone</label>
                <input 
                  type="text" 
                  value={user}
                  onChange={(e) => setUser(e.target.value)}
                  className="w-full bg-zinc-800 border border-white/10 rounded px-3 py-2 text-sm focus:outline-none focus:border-white/30"
                  placeholder="Username"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Password</label>
                <input 
                  type="password" 
                  value={pass}
                  onChange={(e) => setPass(e.target.value)}
                  className="w-full bg-zinc-800 border border-white/10 rounded px-3 py-2 text-sm focus:outline-none focus:border-white/30"
                  placeholder="Password"
                />
              </div>
              <button 
                type="submit"
                className="w-full bg-white text-black font-bold py-2 rounded hover:bg-zinc-200 transition-colors"
              >
                Log In
              </button>
            </form>
            
            <div className="flex items-start gap-2 p-3 bg-zinc-950 rounded border border-white/5">
              <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
              <p className="text-[10px] text-zinc-400 leading-relaxed">
                This simulation demonstrates how malicious actors use fake interfaces to trick users into revealing sensitive data.
              </p>
            </div>
          </div>
        ) : (
          <div className="text-center space-y-4 animate-in fade-in slide-in-from-top-4">
            <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto border border-red-500/40">
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
            <h3 className="text-xl font-bold text-white">DATA INTERCEPTED!</h3>
            <div className="bg-black/50 p-4 rounded-xl border border-white/10 font-mono text-left max-w-xs mx-auto">
              <div className="text-xs text-zinc-500 mb-2">// Captured Payload</div>
              <div className="text-sm">
                <span className="text-green-500">username:</span> "{user}"<br/>
                <span className="text-green-500">password:</span> "{pass}"
              </div>
            </div>
            <p className="text-zinc-400 text-sm max-w-md mx-auto">
              You've just witnessed a <span className="text-red-400 font-bold">Credential Harvesting</span> attack. 
              The hacker now has full control of the account. This is the primary method behind "Roblox Hacking" videos you see online.
            </p>
            <button 
              onClick={() => setIsIntercepted(false)}
              className="px-6 py-2 bg-zinc-800 text-white rounded-lg font-bold hover:bg-zinc-700 transition-all text-sm"
            >
              Reset Simulation
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
