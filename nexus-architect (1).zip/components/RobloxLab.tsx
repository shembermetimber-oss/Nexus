
import React, { useState } from 'react';
import { Code, Box, Terminal, X, Zap, ChevronRight, Play, Copy, Check, ShieldCheck, RefreshCw, ClipboardCheck } from 'lucide-react';

export const RobloxLab: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [code, setCode] = useState('-- Nexus Roblox Plugin Helper\nlocal Players = game:GetService("Players")\n\nPlayers.PlayerAdded:Connect(function(player)\n    print("Welcome to the Nexus Core, " .. player.Name)\nend)');
  const [status, setStatus] = useState('System Idle: Waiting for Luau Directive');
  const [copied, setCopied] = useState(false);
  const [isChecking, setIsChecking] = useState(false);

  const runSim = () => {
    setStatus('Compiling Luau Bytecode...');
    setTimeout(() => setStatus('Simulation Success: RemoteEvents Sanitized and Re-routed.'), 1500);
  };

  const syntaxCheck = () => {
    setIsChecking(true);
    setStatus('Verifying Lexical Luau structure...');
    setTimeout(() => {
      setIsChecking(false);
      setStatus('Syntax Valid: Protocol integrity verified. No memory leaks detected.');
    }, 2000);
  };

  const copyScript = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full bg-[#0d1117] rounded-[2.5rem] border border-red-500/30 overflow-hidden flex flex-col animate-in slide-in-from-right duration-500 shadow-2xl">
      <div className="bg-red-500/10 px-8 py-5 flex items-center justify-between border-b border-red-500/20">
        <div className="flex items-center gap-4 text-red-500">
          <Box className="w-6 h-6" />
          <span className="text-[11px] font-black tracking-[0.4em] uppercase mono">Roblox Luau Engine // CIPHER_CORE</span>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-all">
          <X className="w-5 h-5 text-zinc-500" />
        </button>
      </div>

      <div className="p-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-black/50 rounded-3xl border border-white/5 relative group overflow-hidden shadow-inner">
            <div className="flex items-center justify-between px-6 py-4 bg-zinc-900/60 border-b border-white/5 backdrop-blur-md">
              <div className="flex items-center gap-3 text-zinc-500 text-[10px] uppercase font-black tracking-widest">
                <Code className="w-4 h-4" /> Luau Editor
              </div>
              <button 
                onClick={copyScript}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all border ${
                  copied ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400' : 'bg-red-500/10 hover:bg-red-500/20 border-red-500/20 text-red-400'
                }`}
              >
                {copied ? <ClipboardCheck className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Protocol_Saved' : 'Extract_Script'}
              </button>
            </div>
            <textarea 
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full h-80 bg-transparent border-none outline-none mono text-[13px] text-red-400/90 resize-none p-8 selection:bg-red-500/20 custom-scrollbar leading-relaxed"
              spellCheck={false}
              autoFocus
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={syntaxCheck}
              disabled={isChecking}
              className="py-5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 font-black uppercase text-[11px] tracking-[0.2em] rounded-2xl border border-white/5 transition-all flex items-center justify-center gap-3 shadow-lg active:scale-95 disabled:opacity-50"
            >
              {isChecking ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              Syntax_Validator
            </button>
            <button 
              onClick={runSim}
              className="py-5 bg-red-600 hover:bg-red-500 text-white font-black uppercase text-[11px] tracking-[0.2em] rounded-2xl transition-all flex items-center justify-center gap-3 shadow-xl shadow-red-600/30 active:scale-95"
            >
              <Zap className="w-4 h-4 fill-current" /> Inject_Protocol
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-black p-8 rounded-[2rem] border border-white/5 flex flex-col h-full min-h-[350px] shadow-2xl">
             <div className="text-[10px] font-black text-zinc-700 uppercase mb-8 tracking-[0.4em] flex items-center justify-between border-b border-white/5 pb-4">
               Tactical_Output_Console
               <div className="flex gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.8)]"></div>
                  <div className="w-1.5 h-1.5 rounded-full bg-zinc-800"></div>
               </div>
             </div>
             <div className="mono text-[12px] space-y-4 overflow-y-auto custom-scrollbar flex-1 pr-4">
                <div className="text-zinc-700 flex items-center gap-3">
                   <span className="text-[10px] text-zinc-800 font-black">[{new Date().toLocaleTimeString()}]</span>
                   VM Initialization Complete.
                </div>
                <div className="text-zinc-700 flex items-center gap-3">
                   <span className="text-[10px] text-zinc-800 font-black">[{new Date().toLocaleTimeString()}]</span>
                   Luau Nexus Bridge Established.
                </div>
                <div className="text-zinc-500 italic mt-6 border-l-2 border-red-500/20 pl-4">
                   -- Standby for Luau execution --
                </div>
                <div className="text-red-400 font-bold flex items-start gap-4 mt-4 bg-red-500/5 p-4 rounded-xl border border-red-500/10">
                   <ChevronRight className="w-4 h-4 mt-1 flex-shrink-0" /> 
                   <span>{status}</span>
                </div>
             </div>
          </div>
          <div className="p-6 rounded-[1.5rem] bg-red-500/5 border border-red-500/10 flex items-center gap-6 group hover:border-red-500/30 transition-all">
            <div className="p-4 bg-red-500/10 rounded-2xl group-hover:bg-red-500/20 transition-all">
              <RefreshCw className="w-7 h-7 text-red-500 cyber-glow" />
            </div>
            <div>
              <div className="text-[11px] font-black text-white uppercase tracking-widest mb-1">Compiler Statistics</div>
              <div className="text-[13px] text-zinc-600 font-bold uppercase tracking-tight">14ms latency // Thread_Secure_Sync</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
