
export enum LessonCategory {
  NETWORKING = 'Networking',
  WEB_SECURITY = 'Web Security',
  CRYPTOGRAPHY = 'Cryptography',
  LINUX_BASICS = 'Linux Basics',
  SOCIAL_ENGINEERING = 'Social Engineering',
  AI_ENGINEERING = 'AI Engineering',
  SINGULARITY = 'Singularity',
  ROBLOX_ENGINE = 'Roblox Engine'
}

export interface Lesson {
  id: string;
  title: string;
  category: LessonCategory;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Godlike';
  description: string;
  content: string;
  hasLab?: boolean;
  labType?: 'phishing' | 'ai-builder' | 'llm-architect' | 'roblox-plugin' | 'quantum-sim' | 'swarm-sandbox';
}

export interface TerminalLine {
  text: string;
  type: 'input' | 'output' | 'error' | 'success';
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  sources?: GroundingSource[];
}
