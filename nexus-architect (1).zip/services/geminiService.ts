
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SYSTEM_INSTRUCTION, NEXUS_TOOLS } from "../constants";

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface MentorResponse {
  text: string;
  sources?: GroundingSource[];
  functionCalls?: any[];
}

export const getMentorStream = async (
  prompt: string,
  history: { role: 'user' | 'model', parts: { text: string }[] }[] = [],
  onChunk: (text: string) => void
): Promise<MentorResponse> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const config: any = {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.7,
      topP: 0.8,
      tools: [{ functionDeclarations: NEXUS_TOOLS }]
    };

    // Use gemini-3-flash-preview for maximum speed as requested
    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config,
    });

    let fullText = "";
    let functionCalls: any[] = [];
    let sources: GroundingSource[] = [];

    for await (const chunk of responseStream) {
      const chunkText = chunk.text;
      if (chunkText) {
        fullText += chunkText;
        onChunk(fullText);
      }

      // Check for function calls in chunks
      if (chunk.functionCalls) {
        functionCalls = [...functionCalls, ...chunk.functionCalls];
      }

      // Extract grounding metadata if available
      const chunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        chunks.forEach((c: any) => {
          if (c.web && c.web.uri) {
            sources.push({
              title: c.web.title || c.web.uri,
              uri: c.web.uri
            });
          }
        });
      }
    }

    const uniqueSources = Array.from(new Map(sources.map(s => [s.uri, s])).values());

    return { text: fullText, sources: uniqueSources, functionCalls };
  } catch (error) {
    console.error("Gemini Streaming Error:", error);
    return { text: "Error: Neural link interrupted. System link unstable." };
  }
};

// Kept for backward compatibility if needed, but updated to faster model
export const getMentorResponse = async (
  prompt: string, 
  history: { role: 'user' | 'model', parts: { text: string }[] }[] = [],
  useSearch: boolean = false
): Promise<MentorResponse> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const config: any = {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.7,
      topP: 0.8,
      tools: useSearch 
        ? [{ googleSearch: {} }] 
        : [{ functionDeclarations: NEXUS_TOOLS }]
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config,
    });

    const text = response.text || "";
    const functionCalls = response.functionCalls;
    
    const sources: GroundingSource[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web && chunk.web.uri) {
          sources.push({
            title: chunk.web.title || chunk.web.uri,
            uri: chunk.web.uri
          });
        }
      });
    }

    const uniqueSources = Array.from(new Map(sources.map(s => [s.uri, s])).values());

    return { text, sources: uniqueSources, functionCalls };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "Error: Could not retrieve intelligence from the mentor." };
  }
};
