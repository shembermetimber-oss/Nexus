
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';
import { NEXUS_TOOLS } from '../constants';

export interface LiveSessionCallbacks {
  onTranscript: (text: string, role: 'user' | 'model') => void;
  onAudioStart: () => void;
  onAudioEnd: () => void;
  onError: (error: string) => void;
  onToolCall: (fc: any) => Promise<string>;
}

export class GeminiLiveService {
  private ai: any;
  private sessionPromise: Promise<any> | null = null;
  private session: any;
  private inputAudioContext: AudioContext | null = null;
  private outputAudioContext: AudioContext | null = null;
  private nextStartTime = 0;
  private sources = new Set<AudioBufferSourceNode>();
  private stream: MediaStream | null = null;

  constructor() {
    // Guidelines: Create a new GoogleGenAI instance right before making an API call.
  }

  async connect(callbacks: LiveSessionCallbacks) {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Microphone API not supported.");
      }

      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      // Create new instance here to ensure fresh API key
      this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      this.sessionPromise = this.ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = this.inputAudioContext!.createMediaStreamSource(this.stream!);
            const scriptProcessor = this.inputAudioContext!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = this.createBlob(inputData);
              // CRITICAL: Rely on sessionPromise resolves to avoid race conditions.
              this.sessionPromise?.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(this.inputAudioContext!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.toolCall) {
              for (const fc of message.toolCall.functionCalls) {
                const result = await callbacks.onToolCall(fc);
                this.sessionPromise?.then((session) => {
                  session.sendToolResponse({
                    functionResponses: { id: fc.id, name: fc.name, response: { result } }
                  });
                });
              }
            }

            if (message.serverContent?.outputTranscription) {
              callbacks.onTranscript(message.serverContent.outputTranscription.text, 'model');
            } else if (message.serverContent?.inputTranscription) {
              callbacks.onTranscript(message.serverContent.inputTranscription.text, 'user');
            }

            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              callbacks.onAudioStart();
              this.nextStartTime = Math.max(this.nextStartTime, this.outputAudioContext!.currentTime);
              const audioBuffer = await this.decodeAudioData(this.decodeBase64(audioData));
              const source = this.outputAudioContext!.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(this.outputAudioContext!.destination);
              source.addEventListener('ended', () => {
                this.sources.delete(source);
                if (this.sources.size === 0) callbacks.onAudioEnd();
              });
              source.start(this.nextStartTime);
              this.nextStartTime += audioBuffer.duration;
              this.sources.add(source);
            }

            if (message.serverContent?.interrupted) {
              this.sources.forEach(s => { try { s.stop(); } catch(e) {} });
              this.sources.clear();
              this.nextStartTime = 0;
            }
          },
          onerror: (e: any) => callbacks.onError(e.message || "Live Link Error"),
          onclose: () => console.log("Live Link Closed"),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          tools: [{ functionDeclarations: NEXUS_TOOLS }],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction: 'You are Cipher, the elite AI mentor of NEXUS ARCHITECT. The user is "The Commander". You can control the system via tools. Always confirm orders.',
        },
      });

      this.session = await this.sessionPromise;
    } catch (err: any) {
      callbacks.onError(err.message || "Mic Access Denied");
      throw err;
    }
  }

  private createBlob(data: Float32Array): Blob {
    const int16 = new Int16Array(data.length);
    for (let i = 0; i < data.length; i++) int16[i] = data[i] * 32768;
    return {
      data: this.encodeBase64(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  }

  private decodeBase64(base64: string) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  private encodeBase64(bytes: Uint8Array) {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  }

  private async decodeAudioData(data: Uint8Array): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const buffer = this.outputAudioContext!.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
    return buffer;
  }

  disconnect() {
    this.session?.close();
    this.stream?.getTracks().forEach(t => t.stop());
    if (this.inputAudioContext) this.inputAudioContext.close();
    if (this.outputAudioContext) this.outputAudioContext.close();
    this.session = null;
    this.sessionPromise = null;
    this.stream = null;
  }
}
