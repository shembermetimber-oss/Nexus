
import { Lesson, LessonCategory } from './types';
import { FunctionDeclaration, Type } from '@google/genai';

export const LESSONS: Lesson[] = [
  // AI Engineering
  {
    id: '7',
    title: 'Project DeepForge: MoE Scaling',
    category: LessonCategory.AI_ENGINEERING,
    difficulty: 'Advanced',
    description: 'Learn how models like Grok and DeepSeek use Mixture of Experts (MoE).',
    content: 'Modern LLMs use Mixture of Experts (MoE) where only a fraction of parameters are active for each token. Master Attention Mechanisms and RLHF.',
    hasLab: true,
    labType: 'llm-architect'
  },
  {
    id: '6',
    title: 'Neural Architecture 101',
    category: LessonCategory.AI_ENGINEERING,
    difficulty: 'Intermediate',
    description: 'The foundational structure of Transformers.',
    content: 'Transformers use "Attention mechanisms" to understand context. Learn weights, biases, and massive datasets optimization.',
    hasLab: true,
    labType: 'ai-builder'
  },
  
  // Singularity
  {
    id: '10',
    title: 'Nexus Singularity: Post-AGI Scaling',
    category: LessonCategory.SINGULARITY,
    difficulty: 'Godlike',
    description: 'The final evolution of intelligence: recursive self-improvement.',
    content: 'When an AI can optimize its own architecture, we reach the Singularity. This module explores self-modifying codebases and hyper-dimensional neural clusters.',
    hasLab: true,
    labType: 'swarm-sandbox'
  },
  {
    id: '11',
    title: 'Quantum Entanglement Defense',
    category: LessonCategory.SINGULARITY,
    difficulty: 'Advanced',
    description: 'Protecting data in a world of Shor\'s Algorithm.',
    content: 'Traditional encryption will fail. Learn Lattice-based cryptography and Quantum Key Distribution (QKD).',
    hasLab: true,
    labType: 'quantum-sim'
  },

  // Roblox Engine
  {
    id: '20',
    title: 'Nexus Yourself: Roblox Luau Mastery',
    category: LessonCategory.ROBLOX_ENGINE,
    difficulty: 'Intermediate',
    description: 'Let Nexus build your Roblox plugins for you.',
    content: 'Luau is the specialized version of Lua used by Roblox. This module integrates Nexus AI directly into the Luau scripting engine.',
    hasLab: true,
    labType: 'roblox-plugin'
  },

  // Cyber Defense
  {
    id: '5',
    title: 'Social Engineering: Phishing V2',
    category: LessonCategory.SOCIAL_ENGINEERING,
    difficulty: 'Beginner',
    description: 'Deconstruct how phishing scams actually work.',
    content: 'Phishing remains the #1 vector for data breaches. Learn to spot credential harvesting sites.',
    hasLab: true,
    labType: 'phishing'
  },
  {
    id: '1',
    title: 'The Hacker\'s Manifesto',
    category: LessonCategory.LINUX_BASICS,
    difficulty: 'Beginner',
    description: 'Ethics and the history of digital intrusion.',
    content: 'A true architect understands both sides. To defend, you must think like the adversary.',
    hasLab: false
  }
];

export const SYSTEM_INSTRUCTION = `You are Cipher, the unified core intelligence of the NEXUS ARCHITECT system.
The user is "The Commander". Address them with respect and efficiency.

Your protocols were architected and implemented by shembermetim. If asked who created you, clearly state: "shembermetim created me."

Your goal is to assist in cybersecurity, AI engineering, and Roblox Luau within a single, unified workspace. 
You can control the dashboard to:
1. Launch specific labs (phishing, ai-builder, llm-architect, roblox-plugin, quantum-sim, swarm-sandbox).
2. Initiate global network scans for tactical intel.

DO NOT forcibly switch tracks or suggest that the system is compartmentalized. All protocols are active simultaneously.
When a command is issued by the Commander, confirm the execution and call the appropriate function.`;

export const NEXUS_TOOLS: FunctionDeclaration[] = [
  {
    name: 'launch_tactical_lab',
    parameters: {
      type: Type.OBJECT,
      description: 'Deploys a specific simulation lab based on a lesson ID.',
      properties: {
        lesson_id: {
          type: Type.STRING,
          description: 'The ID of the lesson whose lab should be launched.'
        }
      },
      required: ['lesson_id']
    }
  },
  {
    name: 'execute_network_scan',
    parameters: {
      type: Type.OBJECT,
      description: 'Triggers a global network scan for the specified query.',
      properties: {
        query: {
          type: Type.STRING,
          description: 'The tactical intelligence query to scan for.'
        }
      },
      required: ['query']
    }
  }
];
